/*
Welcome to Astronomical!
The Journey to Building a Habitable Planet

Throughout this game, you will be building a planet in order to make it sustainable for life.
At the right hand corner of the screen will be a next button in order to guide you to the next screen.

1.    Type of Planet – Select Gas Giant or Terrestrial via the Buttons

2.    Position the Planet – Utilize the arrow buttons to position your planet in the solar system (find the ideal distance from the sun)


3.    Planet Mass – Use the slider on the right to increase or decrease the planet mass accordingly

4.    Ocean Acidity – pH is a measure of the acidity in a liquid. Anything below a 7 pH is acidic, and anything above is basic. Use the slider to adjust the pH of your planet’s ocean (liquid changes color with pH)

5.    Planet Temperature – Use the right-hand slider to increase or decrease the planet’s temperature

6.    Planet Atmosphere – Select 7 Elements for your atmosphere. Once 7 elements are selected, hit the next button to see whether your planet was habitable.

Good Luck!
*/



import UIKit
import PlaygroundSupport
import AVFoundation

var imageString = ""
var cellAlphaSpeed = Float(-0.025)
extension UIImageView {
  func setImageColor(color: UIColor) {
    let templateImage = self.image?.withRenderingMode(.alwaysTemplate)
    self.image = templateImage
    self.tintColor = color
  }
}
class CustomSlider: UISlider {
override func trackRect(forBounds bounds: CGRect) -> CGRect {
    let point = CGPoint(x: bounds.minX, y: bounds.midY)
    return CGRect(origin: point, size: CGSize(width: bounds.width, height: 20))
}
}
    class EmitterView: UIView {
      let emitterLayer = CAEmitterLayer()

      override init(frame: CGRect) {
        super.init(frame: frame)

        let cell = CAEmitterCell()
        cell.birthRate = 10
        cell.lifetime = 5.0
        cell.velocity = 100
        cell.velocityRange = 50
        cell.emissionLongitude = CGFloat.pi
        cell.spinRange = 5
        cell.scale = 0.5
        cell.scaleRange = 0.25
        cell.color = UIColor(white: 1, alpha: 0.9).cgColor
        cell.alphaSpeed = cellAlphaSpeed
        cell.contents = UIImage(named: imageString)?.cgImage

        emitterLayer.emitterCells = [cell]
        layer.addSublayer(emitterLayer)

        backgroundColor = .white
      }

      required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
      }

        override public func layoutSubviews() {
        super.layoutSubviews()

        emitterLayer.emitterPosition = CGPoint(x: 400 / 2.0, y: -50)
        emitterLayer.emitterShape = CAEmitterLayerEmitterShape.line
        emitterLayer.emitterSize = CGSize(width: 1000, height: 1)
        emitterLayer.renderMode = CAEmitterLayerRenderMode.additive
      }
    }


let frameOfMainView = CGSize(width: 900, height: 700)
let title = UIImage(named: "Picture1")
let imageView = UIImageView(image: title)
imageView.image = title
imageView.frame.size.width = 570
imageView.frame.size.height = 140
imageView.frame.origin.x = 100
imageView.frame.origin.y = 0

//associate whether planet was/wasn't habitable
var gasCheck = [String]()
var phCheck = [Int]()
var positionCheck = [Int]()
var massCheck = [Float]()
var tempCheck = [Float]()
var atmCheck = [String]()

var finCheck = [String]()
let basicPlanet = UIImage(named: "firstplanet")
let planetView = UIImageView(image: basicPlanet)
var elementsClicked = 0

planetView.image = basicPlanet
planetView.isHidden = true

let terPlanet = UIImage(named: "terplanet")
let terplanetView = UIImageView(image: terPlanet)

terplanetView.image = terPlanet
terplanetView.isHidden = true


var gasClicked = false


/*
let frame = CGRect(x: 440, y: 280, width: 150, height: 50)
let textview = UITextField(frame: frame)
textview.borderStyle = .roundedRect
textview.text = ""
textview.isHidden = true
*/
let createPlanet = UILabel(frame: CGRect(x: 200, y: 0, width: 800, height: 80))

createPlanet.center = CGPoint(x: 385, y: 70)
createPlanet.textAlignment = .center
createPlanet.text = "Choose a Type of Planet"
createPlanet.textColor = UIColor(white: 1, alpha: 1)
createPlanet.font = UIFont.systemFont(ofSize: 60, weight: UIFont.Weight.bold)
createPlanet.isHidden = true

let massLabel = UILabel(frame: CGRect(x: 0, y: 490, width: 800, height: 80))

massLabel.textAlignment = .center
massLabel.text = ""
massLabel.textColor = UIColor(white: 1, alpha: 1)
massLabel.font = UIFont.systemFont(ofSize: 53, weight: UIFont.Weight.bold)
massLabel.isHidden = true



let terButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
let terImage = UIImage(named: "terbutton2.png") as UIImage?
terButton.frame = CGRect(x: 400, y: 430, width: 249, height: 85)
terButton.setImage(terImage, for: [])
terButton.contentMode = .center
terButton.imageView?.contentMode = .scaleAspectFit
terButton.isHidden = true

let resetButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
let playagain = UIImage(named: "playagain.png") as UIImage?
resetButton.frame = CGRect(x: 110, y: 430, width: 573.696, height: 195.84)
resetButton.setImage(playagain, for: [])
resetButton.contentMode = .center
resetButton.imageView?.contentMode = .scaleAspectFit
resetButton.isHidden = true

let gasButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
let gasImage = UIImage(named: "gasbutton2.png") as UIImage?
gasButton.frame = CGRect(x: 100, y: 430, width: 249, height: 85)
gasButton.setImage(gasImage, for: [])
gasButton.contentMode = .center
gasButton.imageView?.contentMode = .scaleAspectFit
gasButton.isHidden = true

let finishButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
let finishImage = UIImage(named: "finish.png") as UIImage?
finishButton.frame = CGRect(x: 570, y: 570, width: 249, height: 85)
finishButton.setImage(finishImage, for: [])
finishButton.contentMode = .center
finishButton.imageView?.contentMode = .scaleAspectFit
finishButton.isHidden = true

let nextButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
let nextImage = UIImage(named: "nextButton.png") as UIImage?
nextButton.frame = CGRect(x: 570, y: 570, width: 249, height: 85)
nextButton.setImage(nextImage, for: [])
nextButton.contentMode = .center
nextButton.imageView?.contentMode = .scaleAspectFit
nextButton.isHidden = true


let solarSystem = UIImage(named: "solarsystem")
let systemView = UIImageView(image: solarSystem)
systemView.image = solarSystem
systemView.frame.size.width = 677.35
systemView.frame.size.height = 278.58
systemView.frame.origin.x = 27
systemView.frame.origin.y = 200

systemView.isHidden = true

let oxygen = UIButton(type: UIButton.ButtonType.custom) as UIButton
let oxygenView = UIImage(named: "oxygen.png") as UIImage?
oxygen.frame = CGRect(x: 70, y: 430, width: 100, height: 85)
oxygen.setImage(oxygenView, for: [])
oxygen.contentMode = .center
oxygen.imageView?.contentMode = .scaleAspectFit
oxygen.isHidden = true

let nitrogen = UIButton(type: UIButton.ButtonType.custom) as UIButton
let nitrogenView = UIImage(named: "nitrogen.png") as UIImage?
nitrogen.frame = CGRect(x: 150, y: 430, width: 100, height: 85)
nitrogen.setImage(nitrogenView, for: [])
nitrogen.contentMode = .center
nitrogen.imageView?.contentMode = .scaleAspectFit
nitrogen.isHidden = true

let hydrogen = UIButton(type: UIButton.ButtonType.custom) as UIButton
let hydrogenView = UIImage(named: "hydrogen.png") as UIImage?
hydrogen.frame = CGRect(x: 240, y: 430, width: 100, height: 85)
hydrogen.setImage(hydrogenView, for: [])
hydrogen.contentMode = .center
hydrogen.imageView?.contentMode = .scaleAspectFit
hydrogen.isHidden = true

let zinc = UIButton(type: UIButton.ButtonType.custom) as UIButton
let zincView = UIImage(named: "zinc.png") as UIImage?
zinc.frame = CGRect(x: 310, y: 430, width: 100, height: 85)
zinc.setImage(zincView, for: [])
zinc.contentMode = .center
zinc.imageView?.contentMode = .scaleAspectFit
zinc.isHidden = true

let copper = UIButton(type: UIButton.ButtonType.custom) as UIButton
let copperView = UIImage(named: "copper.png") as UIImage?
copper.frame = CGRect(x: 370, y: 430, width: 100, height: 85)
copper.setImage(copperView, for: [])
copper.contentMode = .center
copper.imageView?.contentMode = .scaleAspectFit
copper.isHidden = true

let nickel = UIButton(type: UIButton.ButtonType.custom) as UIButton
let nickelView = UIImage(named: "nickel.png") as UIImage?
nickel.frame = CGRect(x: 450, y: 430, width: 100, height: 85)
nickel.setImage(nickelView, for: [])
nickel.contentMode = .center
nickel.imageView?.contentMode = .scaleAspectFit
nickel.isHidden = true

let sulfur = UIButton(type: UIButton.ButtonType.custom) as UIButton
let sulfurView = UIImage(named: "sulfur.png") as UIImage?
sulfur.frame = CGRect(x: 470, y: 430, width: 100, height: 85)
sulfur.setImage(sulfurView, for: [])
sulfur.contentMode = .center
sulfur.imageView?.contentMode = .scaleAspectFit
sulfur.isHidden = true

let phosphorus = UIButton(type: UIButton.ButtonType.custom) as UIButton
let phosphorusView = UIImage(named: "phosphorus.png") as UIImage?
phosphorus.frame = CGRect(x: 560, y: 430, width: 100, height: 85)
phosphorus.setImage(phosphorusView, for: [])
phosphorus.contentMode = .center
phosphorus.imageView?.contentMode = .scaleAspectFit
phosphorus.isHidden = true

let arsenic = UIButton(type: UIButton.ButtonType.custom) as UIButton
let arsenicView = UIImage(named: "arsenic.png") as UIImage?
arsenic.frame = CGRect(x: 170, y: 540, width: 100, height: 85)
arsenic.setImage(arsenicView, for: [])
arsenic.contentMode = .center
arsenic.imageView?.contentMode = .scaleAspectFit
arsenic.isHidden = true

let chromium = UIButton(type: UIButton.ButtonType.custom) as UIButton
let chromiumView = UIImage(named: "chromium.png") as UIImage?
chromium.frame = CGRect(x: 260, y: 540, width: 100, height: 85)
chromium.setImage(chromiumView, for: [])
chromium.contentMode = .center
chromium.imageView?.contentMode = .scaleAspectFit
chromium.isHidden = true

let carbon = UIButton(type: UIButton.ButtonType.custom) as UIButton
let carbonView = UIImage(named: "carbon.png") as UIImage?
carbon.frame = CGRect(x: 370, y: 540, width: 100, height: 85)
carbon.setImage(carbonView, for: [])
carbon.contentMode = .center
carbon.imageView?.contentMode = .scaleAspectFit
carbon.isHidden = true


let positionPlanet = UILabel(frame: CGRect(x: 200, y: 0, width: 800, height: 80))
positionPlanet.center = CGPoint(x: 385, y: 70)
positionPlanet.textAlignment = .center
positionPlanet.text = "Position Your Planet"
positionPlanet.textColor = UIColor(white: 1, alpha: 1)
positionPlanet.font = UIFont.systemFont(ofSize: 60, weight: UIFont.Weight.bold)
positionPlanet.isHidden = true

let habitable = UILabel(frame: CGRect(x: 380, y: 400, width: 800, height: 80))
habitable.center = CGPoint(x: 385, y: 140)
habitable.textAlignment = .center
habitable.text = "Position Your Planet"
habitable.textColor = UIColor(white: 1, alpha: 1)
habitable.font = UIFont.systemFont(ofSize: 35, weight: UIFont.Weight.bold)
habitable.isHidden = true

let reasons = UILabel(frame: CGRect(x: 320, y: 585, width: 800, height: 200))
reasons.center = CGPoint(x: 385, y: 300)
reasons.textAlignment = .center
reasons.text = ""
reasons.textColor = UIColor(white: 1, alpha: 1)
reasons.font = UIFont.systemFont(ofSize: 27, weight: UIFont.Weight.bold)
reasons.isHidden = true

let line = UIImage(named: "line")
let lineView = UIImageView(image: line)
lineView.image = line
lineView.frame.size.width = 300
lineView.frame.size.height = 5
lineView.frame.origin.x = 230
lineView.frame.origin.y = 170

let year = UIImage(named: "year")
let yearView = UIImageView(image: year)
yearView.image = year
yearView.frame.size.width = 800
yearView.frame.size.height = 100
yearView.frame.origin.x = 0
yearView.frame.origin.y = 240

let m2 = UIImage(named: "m2")
let m2View = UIImageView(image: m2)
m2View.image = m2
m2View.frame.size.width = 900
m2View.frame.size.height = 170
m2View.frame.origin.x = -60
m2View.frame.origin.y = 240

let m3 = UIImage(named: "c3")
let m3View = UIImageView(image: m3)
m3View.image = m3
m3View.frame.size.width = 900
m3View.frame.size.height = 170
m3View.frame.origin.x = -60
m3View.frame.origin.y = 240

let m4 = UIImage(named: "c4")
let m4View = UIImageView(image: m4)
m4View.image = m4
m4View.frame.size.width = 800
m4View.frame.size.height = 100
m4View.frame.origin.x = 0
m4View.frame.origin.y = 240


let AUNotifier = UILabel(frame: CGRect(x: 200, y: 0, width: 800, height: 80))
AUNotifier.center = CGPoint(x: 385, y: 130)
AUNotifier.textAlignment = .center
AUNotifier.text = "1 AU = Distance between Sun and Earth"
AUNotifier.textColor = UIColor(white: 1, alpha: 1)
AUNotifier.font = UIFont.systemFont(ofSize: 20, weight: UIFont.Weight.medium)
AUNotifier.isHidden = true

let tempSlider = UISlider()
tempSlider.center = CGPoint(x:500, y:340)
tempSlider.tintColor = UIColor(white: 1, alpha: 1)
tempSlider.minimumValue = -60
tempSlider.maximumValue = 150
tempSlider.frame.size.width = 400
tempSlider.isHidden = true
tempSlider.value = -60
tempSlider.layer.cornerRadius = 5;
tempSlider.minimumTrackTintColor = UIColor(red: 255/255, green: 51/255, blue: 90/255, alpha: 1)
tempSlider.maximumTrackTintColor = UIColor(red: 0/255, green: 0/255, blue: 255/255, alpha: 1)
tempSlider.transform=tempSlider.transform.rotated(by: CGFloat(270.0/180*(.pi)));

let ph = UILabel(frame: CGRect(x: 200, y: 100, width: 800, height: 80))
ph.center = CGPoint(x: 385, y: 330)
ph.textAlignment = .center
ph.text = ""
ph.textColor = UIColor(white: 0, alpha: 1)
ph.font = UIFont.systemFont(ofSize: 40, weight: UIFont.Weight.medium)
ph.isHidden = true


let massSlider = UISlider()
massSlider.center = CGPoint(x:540, y:300)
massSlider.tintColor = UIColor(white: 1, alpha: 1)
massSlider.minimumValue = 0.01
massSlider.frame.size.width = 400
massSlider.maximumValue = 5
massSlider.isHidden = true
massSlider.layer.cornerRadius = 5;
massSlider.value = 18.8
massSlider.transform=massSlider.transform.rotated(by: CGFloat(270.0/180*(.pi)));
massSlider.value = 0

let distanceValue = UILabel(frame: CGRect(x: -8, y: 485, width: 800, height: 80))
distanceValue.textAlignment = .center
distanceValue.textColor = UIColor(white: 1, alpha: 1)
distanceValue.font = UIFont.systemFont(ofSize: 30, weight: UIFont.Weight.bold)
distanceValue.isHidden = false

let waterBack = UIImageView(image: UIImage(named: "back"))
waterBack.setImageColor(color: UIColor.purple)
waterBack.frame.origin.x = -100
waterBack.frame.origin.y = 450
waterBack.frame.size.width = 1000
waterBack.frame.size.height = 370

waterBack.isHidden = true

let incrementArray = [5.2,6.9,0.2,0.3,0.7,0.2]

let rightButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
let rightImage = UIImage(named: "rightButton.png") as UIImage?
rightButton.frame = CGRect(x: 450, y: 500, width: 48, height: 48)
rightButton.setImage(rightImage, for: [])
rightButton.contentMode = .center
rightButton.imageView?.contentMode = .scaleAspectFit
rightButton.isHidden = true


let leftButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
let leftImage = UIImage(named: "leftButton.png") as UIImage?
leftButton.frame = CGRect(x: 280, y: 500, width: 48, height: 48)
leftButton.setImage(leftImage, for: [])
leftButton.contentMode = .center
leftButton.imageView?.contentMode = .scaleAspectFit
leftButton.isHidden = true

let waterTable = UIImage(named: "waterTable")
let waterView = UIImageView(image: waterTable)
waterView.image = waterTable
waterView.frame.size.width = 1100
waterView.frame.size.height = 250
waterView.frame.origin.x = -180
waterView.frame.origin.y = 467

waterView.isHidden = true

let slider = UISlider()
slider.minimumValue = 1
slider.maximumValue = 14
slider.frame.size.width = 360
slider.frame.origin.x = 220
slider.frame.origin.y = 200
slider.isHidden = true

var audioPlayer : AVAudioPlayer!
var complete = false

class MyViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        func startRun () {
            view.backgroundColor = UIColor(patternImage: UIImage(named: "astronomical.png")!)
                
                
                let button = UIButton(type: UIButton.ButtonType.custom) as UIButton
                button.setTitle("Click here", for: UIControl.State.normal)
                let image = UIImage(named: "startbutton4.png") as UIImage?
                button.frame = CGRect(x: 265, y: 300, width: 249, height: 85)
                button.setImage(image, for: [])
                button.contentMode = .center
                button.imageView?.contentMode = .scaleAspectFit
                imageView.alpha = 0
            
                UIView.animate(withDuration: 3, delay: 2, options: .curveEaseOut, animations: {
                   imageView.alpha = 1
                }, completion: nil)
                button.imageView?.contentMode = .scaleAspectFit
                button.addTarget(self, action: #selector(buttonAction), for: .touchDown)
                gasButton.addTarget(self, action: #selector(gasButtonAction), for: .touchDown)
                terButton.addTarget(self, action: #selector(terButtonAction), for: .touchDown)
                rightButton.addTarget(self, action: #selector(rightSelect), for: .touchDown)
                leftButton.addTarget(self, action: #selector(leftSelect), for: .touchDown)
                nextButton.addTarget(self, action: #selector(nextClicked), for: UIControl.Event.touchDown)
                massSlider.addTarget(self, action: #selector(sliderMoved), for: .valueChanged)
                slider.addTarget(self, action: #selector(valChanged), for: .valueChanged)
                tempSlider.addTarget(self, action: #selector(tempChanged), for: .valueChanged)
                arsenic.addTarget(self, action: #selector(molecule), for: .touchDown)
                sulfur.addTarget(self, action: #selector(molecule), for: .touchDown)
                carbon.addTarget(self, action: #selector(molecule), for: .touchDown)
                hydrogen.addTarget(self, action: #selector(molecule), for: .touchDown)
                nitrogen.addTarget(self, action: #selector(molecule), for: .touchDown)
                chromium.addTarget(self, action: #selector(molecule), for: .touchDown)

                nickel.addTarget(self, action: #selector(molecule), for: .touchDown)
                copper.addTarget(self, action: #selector(molecule), for: .touchDown)
                zinc.addTarget(self, action: #selector(molecule), for: .touchDown)
                oxygen.addTarget(self, action: #selector(molecule), for: .touchDown)
                phosphorus.addTarget(self, action: #selector(molecule), for: .touchDown)
                phosphorus.addTarget(self, action: #selector(molecule), for: .touchDown)
                finishButton.addTarget(self, action: #selector(finish), for: .touchDown)

                
                self.view.addSubview(button)
                self.view.addSubview(terButton)
                self.view.addSubview(gasButton)
                
                view.addSubview(imageView)
                view.addSubview(planetView)
                view.addSubview(createPlanet)
                view.addSubview(terplanetView)
                view.addSubview(systemView)
                view.addSubview(positionPlanet)
                view.addSubview(AUNotifier)
                view.addSubview(rightButton)
                view.addSubview(leftButton)
                
                view.addSubview(distanceValue)
                view.addSubview(nextButton)
                view.addSubview(waterView)
                view.bringSubviewToFront(planetView)
                view.bringSubviewToFront(terplanetView)
                view.addSubview(massLabel)
                view.addSubview(massSlider)
                view.bringSubviewToFront(nextButton)
                view.addSubview(ph)
                view.addSubview(slider)
                view.addSubview(waterBack)
                view.sendSubviewToBack(waterBack)
                view.addSubview(tempSlider)
                view.addSubview(finishButton)
                view.addSubview(habitable)
                view.addSubview(carbon)
                view.addSubview(oxygen)
                view.addSubview(nitrogen)
                view.addSubview(phosphorus)
                view.addSubview(nickel)
                view.addSubview(chromium)
                view.addSubview(arsenic)
                view.addSubview(hydrogen)
                view.addSubview(sulfur)
                view.addSubview(zinc)
                view.addSubview(copper)
                view.addSubview(yearView)
                
                view.addSubview(resetButton)
        }
            yearView.alpha = 0
            
            view.addSubview(yearView)
            let sound = Bundle.main.path(forResource: "music", ofType: "mp3")
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
            }
            catch{
                print(error)
            }
            audioPlayer.play()
            view.backgroundColor = UIColor(white: 0, alpha: 1)
            UIView.animate(withDuration: 2, delay: 2/10, options: .curveEaseOut, animations: {
               yearView.alpha = 1
            }, completion: { success in
                if success {
                    UIView.animate(withDuration: 3, delay: 2, options: .curveEaseOut, animations: {
                       yearView.alpha = 0
                    }, completion: { success in
                        if success {
                            m2View.alpha = 0
                            self.view.addSubview(m2View)
                            UIView.animate(withDuration: 2, delay: 0, options: .curveEaseOut, animations: {
                                              m2View.alpha = 1
                            }, completion: {success in
                                if success {
                                    UIView.animate(withDuration: 1, delay: 3, options: .curveEaseOut, animations: {
                                       m2View.alpha = 0
                                    }, completion: {success in
                                        if success {
                                            m3View.alpha = 0
                                            self.view.addSubview(m3View)
                                            UIView.animate(withDuration: 2, delay: 0, options: .curveEaseOut, animations: {
                                               m3View.alpha = 1
                                            }, completion: {success in
                                                if success {
                                                    UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
                                                       m3View.alpha = 0
                                                    }, completion: nil)
                                                    m4View.alpha = 0
                                                    self.view.addSubview(m4View)
                                                    UIView.animate(withDuration: 2, delay: 2, options: .curveEaseOut, animations: {
                                                       m4View.alpha = 1
                                                    }, completion: {success in
                                                        if success {
                                                            UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {
                                                               m4View.alpha = 0
                                                            }, completion: nil)
                                                            startRun()
                                                        }
                                                    })
                                                }
                                            })
                                        }
                                    })}
                            })
                            
                        }
                    })
                }
            })
            
        

    }

    @objc func buttonAction(sender: UIButton, secondParams: UIImageView) {
        sender.isHighlighted = false
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
           sender.alpha = 0
        }, completion: { success in
            if success {
                imageView.alpha = 1
                UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                   imageView.alpha = 0
                }, completion: nil)
                
                planetView.alpha = 0
                planetView.isHidden = false
                UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                   planetView.alpha = 1
                }, completion: nil)
                
                planetView.frame.size.width = 530
                planetView.frame.size.height = 700
                planetView.frame.origin.x = -35
                planetView.frame.origin.y = 20
                
            
                createPlanet.alpha = 0
                createPlanet.isHidden = false
                UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
                   createPlanet.alpha = 1
                }, completion: nil)
                
                
                
                terplanetView.alpha = 0
                terplanetView.isHidden = false
                UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                   terplanetView.alpha = 1
                }, completion: nil)
                
                terplanetView.frame.size.width = 405
                               terplanetView.frame.size.height = 532
                               terplanetView.frame.origin.x = 300
                               terplanetView.frame.origin.y = 120
                terButton.alpha = 0
                terButton.isHidden = false
                
                UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
                   terButton.alpha = 1
                }, completion: nil)
                
                gasButton.alpha = 0
                gasButton.isHidden = false
                
                UIView.animate(withDuration: 0.5, delay: 1, options: .curveEaseOut, animations: {
                   gasButton.alpha = 1
                }, completion: nil)
            }
        })
    }
    @objc func gasButtonAction() -> Bool {
        gasButton.isHighlighted = false
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
           gasButton.alpha = 0
        }, completion: nil)
        createPlanet.alpha = 1
        createPlanet.isHidden = false
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
           createPlanet.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
           planetView.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
           terplanetView.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
           terButton.alpha = 0
        }, completion: nil)
        systemView.alpha = 0
        systemView.isHidden = false
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
           systemView.alpha = 1
        }, completion: nil)
        positionPlanet.alpha = 0
        positionPlanet.isHidden = false
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
                          positionPlanet.alpha = 1
                       }, completion: nil)
        AUNotifier.alpha = 0
        AUNotifier.isHidden = false
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
           AUNotifier.alpha = 1
        }, completion: nil)
        rightButton.isHidden = false
        rightButton.alpha = 1
        
        leftButton.isHidden = false
        leftButton.alpha = 1
        nextButton.isHidden = false
        planetView.frame.size.width = 132.5
        planetView.frame.size.height = 175
        planetView.frame.origin.x = 628
        planetView.frame.origin.y = 278.58
        
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
           planetView.alpha = 1
        }, completion: nil)
        distanceValue.isHidden = false
        gasCheck.append("true")
        return (gasClicked == true)
    }
    @objc func terButtonAction() -> Bool {
        terButton.isHighlighted = false
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
           terButton.alpha = 0
        }, completion: nil)
        createPlanet.alpha = 1
        createPlanet.isHidden = false
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
           createPlanet.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {
           planetView.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {
           terplanetView.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
           gasButton.alpha = 0
        }, completion: nil)
        systemView.alpha = 0
        systemView.isHidden = false
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
           systemView.alpha = 1
        }, completion: nil)
        positionPlanet.alpha = 0
             positionPlanet.isHidden = false
             UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
                               positionPlanet.alpha = 1
                            }, completion: nil)
        AUNotifier.alpha = 0
        AUNotifier.isHidden = false
        UIView.animate(withDuration: 2, delay: 1, options: .curveEaseOut, animations: {
           AUNotifier.alpha = 1
        }, completion: nil)
        
        terplanetView.frame.size.width = 107.33
        terplanetView.frame.size.height = 141.75
        terplanetView.frame.origin.x = 628
        terplanetView.frame.origin.y = 278.58
        
        rightButton.isHidden = false
        rightButton.alpha = 1
        nextButton.isHidden = false
        leftButton.isHidden = false
        leftButton.alpha = 1
        distanceValue.isHidden = false
        nextButton.isEnabled = false
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
           terplanetView.alpha = 1
        }, completion: nil)
        gasCheck.append("false")
        return (gasClicked)
    }
    
    @objc func rightSelect() {
        if (distanceValue.text == "") {
            nextButton.isEnabled = false
        }
        rightButton.isHidden = false
        rightButton.alpha = 1

        if ((planetView.frame.origin.x == 580) || (terplanetView.frame.origin.x == 580) ) {
            planetView.frame.origin.x = 628
            terplanetView.frame.origin.x = 628
            distanceValue.text = "13.6 AU"
        }
        if ((planetView.frame.origin.x == 444) || (terplanetView.frame.origin.x == 444) ) {
            planetView.frame.origin.x = 580
            terplanetView.frame.origin.x = 580
            distanceValue.text = "8.4 AU"
        }
        if ((planetView.frame.origin.x == 408) || (terplanetView.frame.origin.x == 408)) {
            planetView.frame.origin.x = 444
            terplanetView.frame.origin.x = 444
            distanceValue.text = "1.5 AU"
        }
        if ((planetView.frame.origin.x == 363) || (terplanetView.frame.origin.x == 363)) {
            planetView.frame.origin.x = 408
            terplanetView.frame.origin.x = 408
            distanceValue.text = "1.3 AU"
        }
        if ((planetView.frame.origin.x == 270) || (terplanetView.frame.origin.x == 270)) {
            planetView.frame.origin.x = 363
            terplanetView.frame.origin.x = 363
            distanceValue.text = "1.0 AU"
        }
        if ((planetView.frame.origin.x == 240) || (terplanetView.frame.origin.x == 240)) {
            planetView.frame.origin.x = 270
            terplanetView.frame.origin.x = 270
            distanceValue.text = "0.3 AU"
        }
    }
    @objc func leftSelect() {
        nextButton.isEnabled = true
            leftButton.isHidden = false
            leftButton.alpha = 1
            if ((planetView.frame.origin.x == 628) || (terplanetView.frame.origin.x == 628)) {
                planetView.frame.origin.x = 580
                terplanetView.frame.origin.x = 580
                distanceValue.text = "8.4 AU"
        }
            else if ((planetView.frame.origin.x == 580) || (terplanetView.frame.origin.x == 580)) {
                planetView.frame.origin.x = 444
                terplanetView.frame.origin.x = 444
                distanceValue.text = "1.5 AU"
            }
            else if ((planetView.frame.origin.x == 444) || (terplanetView.frame.origin.x == 444)) {
                planetView.frame.origin.x = 408
                terplanetView.frame.origin.x = 408
                distanceValue.text = "1.3 AU"
            }
            else if ((planetView.frame.origin.x == 408) || (terplanetView.frame.origin.x == 408)) {
                planetView.frame.origin.x = 363
                terplanetView.frame.origin.x = 363
                distanceValue.text = "1.0 AU"
            }
            else if ((planetView.frame.origin.x == 363) || (terplanetView.frame.origin.x == 363)) {
                planetView.frame.origin.x = 270
                terplanetView.frame.origin.x = 270
                distanceValue.text = "0.3 AU"
            }
            else if ((planetView.frame.origin.x == 270) || (terplanetView.frame.origin.x == 270)) {
                planetView.frame.origin.x = 240
                terplanetView.frame.origin.x = 240
                distanceValue.text = "0.1 AU"
            }
            
        }
    @objc func nextClicked() {
        if ((massSlider.isHidden == false) && (ph.isHidden == false) && (tempSlider.isHidden == false)) {
            tempCheck.append(tempSlider.value)
            positionPlanet.text = "Planet Atmosphere"
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               ph.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               tempSlider.alpha = 0
            }, completion: nil)
            positionPlanet.text = "Planet Atmosphere"
            AUNotifier.text = "Pick 7 Elements"
            carbon.isHidden = false
            hydrogen.isHidden = false
            nitrogen.isHidden = false
            //zinc.isHidden = false
            arsenic.isHidden = false
            chromium.isHidden = false
            copper.isHidden = false
            oxygen.isHidden = false
            sulfur.isHidden = false
            chromium.isHidden = false
            phosphorus.isHidden = false
            finishButton.isHidden = false
            finishButton.isEnabled = false
            nextButton.isHidden = true
        }
        if ((massSlider.isHidden == false) && (ph.isHidden == false) && (tempSlider.isHidden == true)) {
            nextButton.isEnabled = false
            phCheck.append(Int(slider.value.rounded()))
            positionPlanet.text = "Planet Temperature"
            AUNotifier.text = "In Celsius"
           UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
                          slider.alpha = 0
                       }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               waterBack.alpha = 0
            }, completion: nil)
            tempSlider.isHidden = false
            ph.isHidden = false
            ph.text = ""
        }
        if ((massSlider.isHidden == false) && (ph.isHidden == true)) {
            massCheck.append((massSlider.value))
            positionPlanet.isHidden = true
            AUNotifier.isHidden = true
            systemView.isHidden = true
            waterView.isHidden
            
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
                          positionPlanet.alpha = 0
                       }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               AUNotifier.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               massLabel.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               massSlider.alpha = 0
            }, completion: nil)
            if gasCheck == ["false"] {
                UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
                   terplanetView.alpha = 0
                }, completion: nil)
            
                }
            else {
                UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
                   planetView.alpha = 0
                }, completion: nil)
            }
            view.backgroundColor = UIColor(white: 1, alpha: 1)
            positionPlanet.text = "Ocean Acidity"
            AUNotifier.text = "In terms of pH"
            nextButton.isEnabled = false
            positionPlanet.isHidden = false
            AUNotifier.isHidden = false
            positionPlanet.textColor = UIColor(white: 0, alpha: 1)
            AUNotifier.textColor = UIColor(white: 0, alpha: 1)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               positionPlanet.alpha = 1
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               AUNotifier.alpha = 1
            }, completion: nil)
            waterBack.isHidden = false
            slider.isHidden = false
            ph.isHidden = false
            
            
        }
        if ((planetView.isHidden == false) && (systemView.isHidden == false)) {
            positionCheck.append(Int(planetView.frame.origin.x))
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               systemView.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               leftButton.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               rightButton.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               positionPlanet.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               AUNotifier.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               distanceValue.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
               planetView.alpha = 0
            }, completion: nil)
            massSlider.isHidden = false
            massLabel.isHidden = false
            if gasCheck == ["false"] {
                UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
                   terplanetView.alpha = 1
                }, completion: nil)
                terplanetView.frame.size.width = 119.25
                terplanetView.frame.size.height = 157.5
                terplanetView.frame.origin.x = 320
                terplanetView.frame.origin.y = 350
            }
            else {
                UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
                   planetView.alpha = 1
                }, completion: nil)
            planetView.frame.size.width = 119.25
            planetView.frame.size.height = 157.5
            planetView.frame.origin.x = 320
            planetView.frame.origin.y = 350
                }
            nextButton.isEnabled = false
            positionPlanet.text = "Planet Mass"
            AUNotifier.text = "% of Earth's Mass"
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
               positionPlanet.alpha = 1
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
               AUNotifier.alpha = 1
            }, completion: nil)
        }
    }
    @objc func sliderMoved() {
        if gasCheck == ["false"] {
            nextButton.isEnabled = true
            let newMass = round(1000.0 * (massSlider.value)) / 1000.0
            massLabel.text = (String((newMass)) + " %")
            let scale = (massSlider.value * 1.0005)
            let transform = CGAffineTransform.init(scaleX: CGFloat(scale), y: CGFloat(scale))
            terplanetView.transform = transform
        }
        else {
            nextButton.isEnabled = true
            let newMass = round(1000.0 * (massSlider.value)) / 1000.0
            massLabel.text = (String((newMass)) + " %")
            let scale = (massSlider.value * 1.3)
            let transform = CGAffineTransform.init(scaleX: CGFloat(scale), y: CGFloat(scale))
        planetView.transform = transform
        }
    }
    @objc func valChanged() {
        nextButton.isEnabled = true
        slider.value = roundf(slider.value)
        if (slider.value == 1) {
            waterBack.setImageColor(color: UIColor(red: 139/255, green: 0/255, blue: 0/255, alpha: 1))
            ph.text = "1 pH"
        }
        if (slider.value == 2) {
            waterBack.setImageColor(color: UIColor(red: 240/255, green: 128/255, blue: 128/255, alpha: 1))
            ph.text = "2 pH"
        }
        if (slider.value == 3) {
            waterBack.setImageColor(color: UIColor(red: 255/255, green: 140/255, blue: 0/255, alpha: 1))
            ph.text = "3 pH"
        }
        if (slider.value == 4) {
            waterBack.setImageColor(color: UIColor(red: 255/255, green: 127/255, blue: 80/255, alpha: 1))
            ph.text = "4 pH"
        }
        if (slider.value == 5) {
            waterBack.setImageColor(color: UIColor(red: 255/255, green: 165/255, blue: 0/255, alpha: 1))
            ph.text = "5 pH"
        }
        if (slider.value == 6) {
            waterBack.setImageColor(color: UIColor(red: 255/255, green: 160/255, blue: 122/255, alpha: 1))
            ph.text = "6 pH"
        }
        if (slider.value == 7) {
            waterBack.setImageColor(color: UIColor(red: 154/255, green: 205/255, blue: 50/255, alpha: 1))
            ph.text = "7 pH"
        }
        if (slider.value == 8) {
            waterBack.setImageColor(color: UIColor(red: 0/255, green: 100/255, blue: 0/255, alpha: 1))
            ph.text = "8 pH"
        }
        if (slider.value == 9) {
            waterBack.setImageColor(color: UIColor(red: 0/255, green: 128/255, blue: 128/255, alpha: 1))
            ph.text = "9 pH"
        }
        
        if (slider.value == 10) {
            waterBack.setImageColor(color: UIColor(red: 0/255, green: 0/255, blue: 205/255, alpha: 1))
            ph.text = "10 pH"
        }
        if (slider.value == 11) {
            waterBack.setImageColor(color: UIColor(red: 0/255, green: 0/255, blue: 139/255, alpha: 1))
            ph.text = "11 pH"
        }
        if (slider.value == 12) {
            waterBack.setImageColor(color: UIColor(red: 238/255, green: 130/255, blue: 238/255, alpha: 1))
            ph.text = "12 pH"
        }
        if (slider.value == 13) {
            waterBack.setImageColor(color: UIColor(red: 147/255, green: 112/255, blue: 219/255, alpha: 1))
            ph.text = "13 pH"
        }
        if (slider.value == 14) {
            waterBack.setImageColor(color: UIColor(red: 75/255, green: 0/255, blue: 130/255, alpha: 1))
            ph.text = "14 pH"
        }
        
    }
    @objc func tempChanged () {
        nextButton.isEnabled = true
        ph.text = (String(tempSlider.value) + " °C")
    }
    @objc func molecule (sender: UIButton) {
        if (elementsClicked == 6) {
            finishButton.isEnabled = true
            arsenic.isEnabled = false
            sulfur.isEnabled = false
            hydrogen.isEnabled = false
            nitrogen.isEnabled = false
            carbon.isEnabled = false
            chromium.isEnabled = false
            phosphorus.isEnabled = false
            zinc.isEnabled = false
            nickel.isEnabled = false
            oxygen.isEnabled = false
            copper.isEnabled = false
        }
        if (sender == arsenic) {
            atmCheck.append("arsenic")
            imageString = "arsenicmol"
            view.addSubview(EmitterView())
            elementsClicked += 1
            arsenic.isEnabled = false
        }
        if (sender == sulfur) {
            atmCheck.append("sulfur")
            imageString = "sulfurmol"
            view.addSubview(EmitterView())
            elementsClicked += 1
            sulfur.isEnabled = false
        }
        if (sender == hydrogen) {
            atmCheck.append("hydrogen")
            imageString = "hydrogenmol"
            view.addSubview(EmitterView())
            elementsClicked += 1
            hydrogen.isEnabled = false
        }
        if (sender == nitrogen) {
            atmCheck.append("nitrogen")
            imageString = "nitrogenmol"
            view.addSubview(EmitterView())
            elementsClicked += 1
            nitrogen.isEnabled = false
        }
        if (sender == carbon) {
            atmCheck.append("carbon")
            imageString = "carbonmolecule"
            view.addSubview(EmitterView())
            elementsClicked += 1
            carbon.isEnabled = false
    }
        if (sender == chromium) {
            atmCheck.append("chromium")
            imageString = "chromiummol"
            view.addSubview(EmitterView())
            elementsClicked += 1
            chromium.isEnabled = false
        }
        if (sender == phosphorus) {
            atmCheck.append("phosphorus")
            imageString = "phosphorusmol"
            view.addSubview(EmitterView())
            elementsClicked += 1
            phosphorus.isEnabled = false
        }
        if (sender == zinc) {
            atmCheck.append("zinc")
            imageString = "zincmol"
            view.addSubview(EmitterView())
            elementsClicked += 1
            zinc.isEnabled = false
        }
        if (sender == nickel) {
            atmCheck.append("nickel")
            imageString = "nickelmol"
            view.addSubview(EmitterView())
            elementsClicked += 1
            nickel.isEnabled = false
        }
        if (sender == oxygen) {
            atmCheck.append("oxygen")
            imageString = "oxygenmol"
            view.addSubview(EmitterView())
            elementsClicked += 1
            oxygen.isEnabled = false
        }
        if (sender == copper) {
            atmCheck.append("copper")
                   imageString = "coppermol"
                   view.addSubview(EmitterView())
            elementsClicked += 1
            copper.isEnabled = false
               }
    }
    @objc func finish() {
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
           carbon.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
           hydrogen.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
           nitrogen.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
           arsenic.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
           copper.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
           oxygen.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
           sulfur.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
           chromium.alpha = 0
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {
           phosphorus.alpha = 0
        }, completion: nil)
        view.backgroundColor = UIColor(patternImage: UIImage(named: "astronomical.png")!)
        positionPlanet.text = "Final Results"
        habitable.isHidden = false
        habitable.textColor = UIColor(white: 1, alpha: 1)
        for view in self.view.subviews {
            view.removeFromSuperview()
        }
        view.addSubview(positionPlanet)
        view.addSubview(ph)
        view.addSubview(habitable)
        positionPlanet.textColor = UIColor(white: 1, alpha: 1)
        positionPlanet.text = "Final Results"
        habitable.alpha = 0
        UIView.animate(withDuration: 3, delay: 0, options: .curveEaseOut, animations: {
           habitable.alpha = 1
        }, completion: nil)
        habitable.text = "Your Planet was Not Habitable"
        view.addSubview(lineView)
        lineView.alpha = 0
        lineView.isHidden = false
        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {
           habitable.alpha = 1
        }, completion: nil)
        UIView.animate(withDuration: 1.5, delay: 0, options: .curveEaseOut, animations: {
                      lineView.alpha = 1
                   }, completion: nil)
        view.addSubview(resetButton)
        view.addSubview(reasons)
        reasons.alpha = 1
        reasons.isHidden = false
        
        reasons.numberOfLines = 6
        if (gasCheck == ["true"]) {
            reasons.text = reasons.text! + " - Your planet was gaseous\n"
        }
        if (positionCheck[0] < 363) {
            reasons.text = reasons.text! + " - Your planet was too close to the sun\n"
        }
        if (positionCheck[0] > 444) {
            reasons.text = reasons.text! + " - Your planet was too far from the sun\n"
        }
        if (tempCheck[0] > 115) {
                       reasons.text = reasons.text! + " - Your planet was too hot\n"
                   }
        if (tempCheck[0] < -15) {
            reasons.text = reasons.text! + " - Your planet was too cold\n"
        }
        if (phCheck[0] < 6) {
            reasons.text = reasons.text! + " - The oceans were too acidic\n"
        }
        if (phCheck[0] > 9) {
            reasons.text = reasons.text! + " - The oceans were too basic\n"
        }
        if (massCheck[0] < 2.7) {
            reasons.text = reasons.text! + " - Your planet did not have enough mass\n"
        }
            if atmCheck.contains("carbon") {
                finCheck.append("C")
            }
        if atmCheck.contains("hydrogen") {
            finCheck.append("H")
        }
        if atmCheck.contains("nitrogen") {
            finCheck.append("N")
        }
        if atmCheck.contains("oxygen") {
            finCheck.append("O")
        }
        if atmCheck.contains("phosphorus") {
            finCheck.append("P")
        }
        if atmCheck.contains("sulfur") {
            finCheck.append("S")
        }
        if finCheck != ["C", "H", "N", "O", "P", "S"] {
            reasons.text = reasons.text! + " - Your atmosphere was not chemically stable\n"
        }
        if (reasons.text == "") {
            reasons.font = UIFont.systemFont(ofSize: 50, weight: UIFont.Weight.bold)
            imageString = "star2"
            view.addSubview(EmitterView())
            habitable.text = ("Your planet was Habitable")
            reasons.text = ("Congratulations!")
            resetButton.frame = CGRect(x: 300, y: 460, width: 398.4, height: 136)
        }
        }
    
    }


let master = MyViewController()
master.preferredContentSize = frameOfMainView
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = master
